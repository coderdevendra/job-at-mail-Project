from django.apps import AppConfig


class JamappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jamapp'
